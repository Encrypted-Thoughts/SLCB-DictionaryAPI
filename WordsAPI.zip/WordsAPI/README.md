# SLCB-WordsAPI
IN PROGRESS: Adds parameter that can be used to get word info from WordsAPI
